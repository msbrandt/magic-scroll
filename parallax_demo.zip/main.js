jQuery(function($){
  var windowH = $(window).height(); 
  var page = $('#home');

  page.height(windowH);



  function magicScroll(){
  	var st = $(window).scrollTop();
  	var wh = $(window).height();


  	var backPos = st / 1.75;
  	var projPos = st / 2.75;
  	var translateVal = st / 3;
  	var projScroll = st / 6;
  	
  	var fade = st,
  		op = 0,
  		fadeSt = 50,
  		fadeEnd = 1000;

  	if(st<=fadeSt){
  		op = 1;
  	}else if(st<=fadeEnd){
  		op = 1 - st / fadeEnd;
  	}
  	var nav = $('.navbar-inverse');
  	var pg = $('#home');
  	var abpg = $('#about');
  	var prpg = $('#projects');
  	var respg = $('#resume');
  	var conpg = $('#contact');
  	var blkpg = $('#blank-1');

  	var aboutBottom = abpg.offset().top - abpg.height();
  	var projectTop = prpg.offset().top;

  	// console.log(aboutBottom + ' ' + st);

  	var firstPg = document.getElementById('home'),
  		aboutPg = document.getElementById('about'),
  		blankpg = document.getElementById('blank-1'),
  		projectsPg = document.getElementById('projects'),
  		resumePg = document.getElementById('resume'),
  		contactPg = document.getElementById('contact'),
  		hero = document.getElementById('home-content');

  	
  	// hero.addClass('move-elm');
  	// firstPg.style.backgroundPosition = "0px, "+ -backPos +'px';
  	// firstPg.style.transform = "translate(0px, " + -backPos + "px";
  	pg.css('background-position', '0px '+ -backPos +'px');
  	hero.style.transform = "translate(0px, "+ translateVal +"px)";
  	aboutPg.style.transform = "translate(0px, "+ -translateVal +"px)";
  	blankpg.style.transform = "translate(0px, "+ -translateVal +"px)";
  	projectsPg.style.transform = "translate(0px, "+ -translateVal +"px)";
  	resumePg.style.transform = "translate(0px, "+ -translateVal +"px)";
  	contactPg.style.transform = "translate(0px, "+ -translateVal +"px)";

  	if(aboutBottom < st){
  		blkpg.css('background-position', '0px '+ -projPos +'px');
  	
  	}

  	hero.style.opacity = op;
  	// console.log(hero);

  };

  $(window).scroll(function(){
  	magicScroll();
  })


});