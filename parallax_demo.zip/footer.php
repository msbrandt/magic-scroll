<?php ?>
<!-- start of footer section  -->
	<div id="footer">
		<div class="footer_page_wrapper_suvbc">
			<div class="page_padding_suvbc">
				<h4><b>&copy;</b> <?php _e( 'Developed and designed by Mikey Brandt', 'SUVBC_domain' ); ?></h4>
			</div>
		</div>
</div>


</div>

	<script src="<?php echo get_template_directory_uri();?>/main.js"></script>


	<?php  wp_footer(); ?>

</body>
</html>
<?php ?>